package com.mygallery.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF171B24)
private val Accent = Color(0xFF8B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyGalleryApp() }
    }
}

@Composable
fun MyGalleryApp() {
    var tab by remember { mutableStateOf("Photos") }
    var picked by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var notice by remember { mutableStateOf("Choose photos or videos from your phone to get started.") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        picked = uris
        notice = if (uris.isEmpty()) "Nothing selected." else "${uris.size} item(s) selected. Editor tools are the next build step."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Bg) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("MY GALLERY", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Your media, your studio.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.Collections, contentDescription = null, tint = Accent, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Photos", "Videos", "Editor").forEach { item ->
                        FilterChip(
                            selected = tab == item,
                            onClick = { tab = item },
                            label = { Text(item) }
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                if (tab == "Editor") {
                    Text("VIDEO STUDIO", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Select a video to prepare it for editing.", color = Color.LightGray)
                    Spacer(Modifier.height(16.dp))
                    EditorTile("Trim & Crop", "Shorten a video or change its frame")
                    EditorTile("Join Clips", "Combine clips into one video")
                    EditorTile("Remove Clip", "Cut an unwanted section")
                    EditorTile("Background", "Background removal / replacement")
                    EditorTile("Export", "Target quality: up to 4K when supported")
                    Spacer(Modifier.height(18.dp))
                    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Choose a video")
                    }
                } else {
                    Text(if (tab == "Photos") "PHOTO LIBRARY" else "VIDEO LIBRARY", color = Accent, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(notice, color = Color.LightGray, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    if (picked.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().weight(1f).background(Panel, RoundedCornerShape(22.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(if (tab == "Photos") Icons.Default.PhotoLibrary else Icons.Default.VideoLibrary,
                                    contentDescription = null, tint = Accent, modifier = Modifier.size(54.dp))
                                Spacer(Modifier.height(12.dp))
                                Text("Your gallery starts here", color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("Add media from your device", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    } else {
                        LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                            items(picked) { uri ->
                                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Column(Modifier.padding(12.dp)) {
                                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = Accent)
                                        Text(uri.lastPathSegment ?: "Selected item", color = Color.White, maxLines = 2, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { picker.launch(arrayOf(if (tab == "Photos") "image/*" else "video/*")) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (tab == "Photos") "Add Photos" else "Add Videos")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("MY GALLERY  •  DARK EDITION", color = Color.Gray, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun EditorTile(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(15.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MovieEdit, contentDescription = null, tint = Accent)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
