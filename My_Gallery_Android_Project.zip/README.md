# My Gallery — Android starter project

This is the first Android project scaffold for the requested **My Gallery** app:
- Dark interface
- Photos / Videos / Editor tabs
- Android document picker to choose media
- Video editor feature roadmap shown in the Editor tab
- Media3 Transformer dependencies included for the next editing implementation

## Important status
This is a **starter build**, not the finished editor yet. The current screen selects media; it does not yet perform trim, clip joining/removal, background removal, or 4K export. Those require implementing and testing the editing pipeline. 4K export is only possible when the source, codec, and phone hardware support it. Background removal is a separate segmentation/AI feature and may need an on-device model or an online service.

## Build from a phone
The easiest phone-only route is to upload this project to a GitHub repository and use the included GitHub Actions workflow. Open the repository on GitHub in your mobile browser, then go to **Actions** and run **Build My Gallery APK**. Download the generated APK from the workflow artifact and install it (Android may ask you to allow installs from that browser).

## Local build
Open this project in Android Studio on a computer and run `assembleDebug`.
